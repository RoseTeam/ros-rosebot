#include "MotorDriver.h"


  // *****************************FONCTIONS DE CONTROLE MOTEUR *****************************//

  //Attention, les 2 moteurs ne tournent pas dans le meme sens => Attention:engendre bcp d'érreurs !!!

void MotorDriver::Motor1(double vit)  {    
     vit = vit/255; //to go from 255 to 100 percents     
    if ( vit >= 0 ) {      
      
      Motor1Dir = 0; 
      Motor1Vit.write(vit);     
           
    }
    else {
      
      Motor1Dir = 1; 
      Motor1Vit.write(-vit); 
    }
  }
  
void MotorDriver::Motor2(double vit)  {
     vit = vit/255; //to go from 255 to 100 percents
    if ( vit >= 0 ) {        
      Motor2Dir = 0; 
      Motor2Vit.write(vit);     
    }
    else {    
      Motor2Dir = 1; 
      Motor2Vit.write(-vit);            
    }
  }
