#include "mbed.h"
#include "SerialCom.h"
#include "MotorCtrl.h"
#include "MotorDriver.h"


 
DigitalOut myled(LED1);
 
//------------------------------------
// Hyperterminal configuration
// 115200 bauds, 8-bit data, no parity
//------------------------------------

Serial pc(SERIAL_TX, SERIAL_RX); //activate the serial port as an object

 
SerialCom ComPC(pc);   //handles all the data RX and save them in private variables (coefficient and command ctrl)

Ticker ticker_motor_ctrl;  //handles the motor control loop frequency


MotorCtrl asser(ComPC);  // handles the motor control algorithm (access to ComPc to know the orders)
//MotorDriver motors(MOTOR_1VIT,MOTOR_1DIR,MOTOR_2VIT,MOTOR_2DIR);

Timer t_com;
Timer t_debug;



 
int main() {
  pc.attach(&ComPC, &SerialCom::serialCallback);
  ticker_motor_ctrl.attach(&asser, &MotorCtrl::Control_interrupt, 1.0/TE);
    
  t_com.start();
  t_debug.start();    
  
  //TODO: Enable a WatchDog !!!
  
  pc.printf("DSys Rdy !!\n");
  
  while (1){
   
   if (t_com.read_ms() > 50)
      {
        pc.printf("X%ld!",long(asser.getODO_X()*100));
        pc.printf("Y%ld!",long(asser.getODO_Y()*100));
        pc.printf("A%ld!",long(asser.getODO_Theta()*100));
        
        pc.printf("K%ld!",long(asser.getODO_SPEED_X()*100));
        pc.printf("G%ld!",long(asser.getODO_SPEED_Y()*100));
        pc.printf("H%ld!",long(asser.getODO_SPEED_Theta()*100));
        
        pc.printf("L%ld!",asser.getWheelL());
        pc.printf("R%ld!",asser.getWheelR()); 
        t_com.reset();
      }
   
   if (t_debug.read_ms() > 1000)
        {      
 
        //pc.printf("Dcoucou!");
        asser.Debug();
      
        
        myled = !myled;
        t_debug.reset();
        }
    
   }
}
 