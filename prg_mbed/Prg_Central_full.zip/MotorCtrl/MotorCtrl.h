#ifndef MOTOR_CTRL_H
#define MOTOR_CTRL_H
 
#include "mbed.h"
#include "QEI.h"
#include "SerialCom.h"
#include "MotorDriver.h"

#define Encoder1_A PC_10//D6//PA_3
#define Encoder1_B PC_12//D7//PA_2

#define Encoder2_A PB_1
#define Encoder2_B PB_2


#define TE 100                     // Temps d'échantiollonnage voulu  
#define R_WHEEL 35                // rayon des roues codeuses
#define WHEEL_B 187               // écartement des roues codeuses
#define ENCODER_RES 5600          // Nombre de ticks par tour de roue

//29.7 tick/mm



class MotorCtrl {
    
public:    

    MotorCtrl(SerialCom& _comPC);  //COnstructor 
    //MotorCtrl();  //COnstructor   
 
  
    void CalculVitesse();  //Computes the current speed of the robot
    
    void Control_interrupt();  //call temporal interrupt functions
    void Odometry();
    void SystemCtrl();
    
    void Debug();

    double getODO_X();
    double getODO_Y();
    double getODO_Theta();    
    
    double getODO_SPEED_X();
    double getODO_SPEED_Y();
    double getODO_SPEED_Theta();
    
    long getWheelL();
    long getWheelR();
    
    float Compute_PID_Angle(float feedbackAspeed, float setpointAspeed);
    float Compute_PID_Linear(float feedbackLspeed, float setpointLspeed);
    
    int pidL;
    int pidR ;
    
    float pidA;
    float pidT ;
    
    
private:  

    float delta_d;
    float delta_g;
    float delay; // 1 sec

    volatile long encoder1Pos;   // ce sont les 2 entier ultra important sur lesquels repose les encodeur, l'odomètrie et l'asservicement
    volatile long encoder2Pos;   // volatile ne sert à rien^^
    double encoder_position_old1, encoder_position_old2; 
      
    
    double ODO_X , ODO_Y , ODO_Theta , ODO_khi, ODO_ds; // variable de position initialisées
    double ODO_SPEED_X, ODO_SPEED_Y, ODO_SPEED_Theta; //variables de vitesses
    
    
    double ODO_DELTA_X , ODO_DELTA_Y;
      
    int mode_deplacement;// sert à déffinir le mode de déplacement : polaire, linèaire...(ici 1 seul mode)
     
  
    int vitesse_roue_1, vitesse_roue_2, vitesse;
    
    long distance;
    long orientation;
    
   // DigitalOut _pin;
   

    QEI wheelL;
    QEI wheelR;
    
    SerialCom& ComPC;
    
    MotorDriver Motors;

};
#endif 