#include "MotorCtrl.h"
#include "mbed.h"


MotorCtrl::MotorCtrl(SerialCom& _ComPC) : ComPC(_ComPC), wheelL(Encoder1_A, Encoder1_B, NC, ENCODER_RES),wheelR(Encoder2_A, Encoder2_B, NC, ENCODER_RES)
{
    ODO_X = 0;
    ODO_Y = 0;
    ODO_Theta = 0;
    ODO_khi = 0.0;
    ODO_ds=0.0;
 // variable de position initialisées
          
    mode_deplacement = 1;// sert à déffinir le mode de déplacement : polaire, linèaire...(ici 1 seul mode)       
}



  
void MotorCtrl::CalculVitesse()
  {
     distance = (wheelL.getPulses() + wheelR.getPulses() )/2;

     orientation = wheelL.getPulses() - wheelR.getPulses() ;
     
     vitesse_roue_1 = wheelL.getPulses()  - encoder_position_old1; /// Calcul des vitesses des roues (le nombre de tic fait depuis la dernière fois)
     encoder_position_old1 = wheelL.getPulses() ;
     
     vitesse_roue_2 = wheelR.getPulses() - encoder_position_old2;
     encoder_position_old2 = wheelR.getPulses(); 
     
     vitesse = (vitesse_roue_1 +vitesse_roue_2)/2;
     
  
  }
  
  
   
    
    
void MotorCtrl::Odometry()
  {  
  
    int ntickd = vitesse_roue_1; 
    int ntickg = vitesse_roue_2;   
   
 
    delta_d = ntickd*2*3.1415/ENCODER_RES;// angle rotation en radians!!!
    delta_g = ntickg*2*3.1415/ENCODER_RES; // 5600= points par tour
      
    ODO_ds = R_WHEEL * (delta_g  + delta_d)/2.0  ; // mesure l'avance
    ODO_Theta = 2*3.1415*R_WHEEL/(WHEEL_B * ENCODER_RES)*(orientation); //  mesure la rotation en radian
    
    ODO_DELTA_X = ODO_ds* cos(ODO_Theta);
    ODO_DELTA_Y = ODO_ds* sin(ODO_Theta);  

    ODO_X = ODO_X + ODO_DELTA_X;
    ODO_Y = ODO_Y + ODO_DELTA_Y;  
  }
  
void MotorCtrl::SystemCtrl(){    

    static float setpointAConsigne = 0; 
    static float setpointLConsigne= 0;
    
    setpointAConsigne = setpointAConsigne + ComPC.getTtwist()/100.0;
    setpointLConsigne = setpointLConsigne + ComPC.getVtwist()/100.0;
    static float OLD_ODO_Theta = 0.0 ; 
    
    
    //float feedbackAspeed = (ODO_Theta - OLD_ODO_Theta)*TE;  
    float feedbackA = orientation ;
    //float feedbackLspeed = ODO_ds / ENCODER_RES * TE;
    float feedbackL = distance; 
    
    ODO_SPEED_Theta = feedbackA;
    OLD_ODO_Theta = ODO_Theta;
    
    float orien = Compute_PID_Angle(feedbackA, setpointAConsigne);
    float dist = Compute_PID_Linear(feedbackL, setpointLConsigne);
    
    pidA = orien;
    pidT = dist; 
    
    float motorL = dist - orien;
    float motorR = dist + orien;
        
    if (motorL > 255) {motorL = 255;}
    else if (motorL < -255) {motorL = -255;}
    if (motorR > 255) {motorR = 255;}
    else if (motorR < -255) {motorR = -255;}
    
    pidL = motorL;
    pidR = motorR;
    
    if(ComPC.getUPower()){
        Motors.Motor1(motorL);
        Motors.Motor2(motorR);
    }
    else {
        Motors.Motor1(0);
        Motors.Motor2(0);
    }

}
  
void MotorCtrl::Control_interrupt()
{
    
  ///////The 3 functions are timely linked--------------------------------------------------------------------///
    CalculVitesse(); //DO NOT CALL IT WITHOUT Odometry FOLLOWING                                             |
    Odometry(); // DO NOT CALL IT WITHOUT SystemCtrl FOLLOWING                                               |
    SystemCtrl(); //  DO NOT CALL IT WITHOUT Odometry PRECEDING  because of intercorrelated variables        |
  /////The 3 functions are timely linked---------------------------------------------------------------------////
}



float MotorCtrl::Compute_PID_Angle(float feedbackAspeed, float setpointAspeed)
{
     float error = setpointAspeed - feedbackAspeed;
     static float old_error = 0.0;
     float error_dif = error - old_error;
     old_error = error;
     
     static float error_int = 0.0;
     error_int+=error;
     
     float P = error*ComPC.getKpPoAng();
     float D = error_dif *ComPC.getKdPoAng();
     float I = error_int *ComPC.getKiPoAng();
     
     if (I > ComPC.getKiPoAngSat())
       { I = ComPC.getKiPoAngSat(); }
     else if (I < -ComPC.getKiPoAngSat())
       { I = -ComPC.getKiPoAngSat(); }
     
     float res = P + I + D;
     
     return res;      
}



float MotorCtrl::Compute_PID_Linear(float feedbackLspeed, float setpointLspeed)
{
     float error = setpointLspeed - feedbackLspeed;
     static float old_error = 0.0;
     float error_dif = error - old_error;
     old_error = error;
     
     static float error_int = 0.0;
     error_int+=error;
     
     float P = error*ComPC.getKpPoLin();
     float D = error_dif *ComPC.getKdPoLin();
     float I = error_int *ComPC.getKiPoLin();
     
     if (I > ComPC.getKiPoLinSat())
       { I = ComPC.getKiPoLinSat(); }
     else if (I < -ComPC.getKiPoLinSat())
       { I = -ComPC.getKiPoLinSat(); }
    
    float res = P + I + D;
     
    return (res);      
}


double MotorCtrl::getODO_X(){
    return ODO_X;
}

double MotorCtrl::getODO_Y(){
    return ODO_Y;
}

double MotorCtrl::getODO_Theta(){
    return ODO_Theta;
}

double MotorCtrl::getODO_SPEED_X(){
    return ODO_DELTA_X*TE;
}

double MotorCtrl::getODO_SPEED_Y(){
    return ODO_DELTA_Y*TE;
}

double MotorCtrl::getODO_SPEED_Theta()
{
    return ODO_SPEED_Theta;
}

long MotorCtrl::getWheelL()
{
    return wheelL.getPulses();
}

long MotorCtrl::getWheelR()
{
    return wheelR.getPulses();
}

void MotorCtrl::Debug(){
    
      ComPC.sendFeedback(ODO_X,ODO_X,pidA,pidT);
        
}
