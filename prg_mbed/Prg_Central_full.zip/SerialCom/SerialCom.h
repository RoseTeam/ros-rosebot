#ifndef SERIAL_COM_H
#define SERIAL_COM_H
 
#include "mbed.h"

#define NBR_CHAR_NAV 16

#define KP_POLAR_ANGLE 15.150
#define KD_POLAR_ANGLE 0.0
#define KI_POLAR_ANGLE 0.0
#define KI_POLAR_ANGLE_SAT 100.0

#define KP_POLAR_LINEAR 500
#define KD_POLAR_LINEAR 0.0
#define KI_POLAR_LINEAR 0.0
#define KI_POLAR_LINEAR_SAT 100.0

class SerialCom {
    
public:    

    SerialCom(Serial& _pc);  //COnstructor 

    void serialCallback(); //function to be called when an event occure on the serial bus (basically store the message type and the message byte in an array if relevant)
    int interpretData(); //Function to be called when we received the full packet
    
    int stateCheck();   // Function which changes internal variable when the satus of the robot has been updates
    
    int getTtwist();
    int getVtwist();
    int getSStatus();
    bool getUPower() ;
    
    float getKpPoLin();     // motor ctrl coeff accesors
    float getKiPoLin();
    float getKdPoLin();
    float getKiPoLinSat();
    float getKpPoAng();
    float getKiPoAng();
    float getKdPoAng();
    float getKiPoAngSat();
    
    bool initCst();
    
    void sendFeedback(long pidL, long pidR, float pidA, float pidT);
    
private:  
    char inputString[NBR_CHAR_NAV];
    char incomming_message_type;
    char nbr_incom_char;
    long incom_data; 
    
    
    bool sign;
    
    long Xorder;  // Commands data from the PC/ROS node
    long Yorder;   
    long Aorder;
    int Lspeed;
    int Rspeed;
    int Ttwist;
    int Vtwist;
    int SStatus;
    bool UPower;
    
   
    
    float KpPoLin;  //Polar, linear proportional coefficient
    float KiPoLin;
    float KdPoLin;
    float KiPoLinSat; //Saturation value for integral term
    
    float KpPoAng;  //Polar, angular proportional coefficient
    float KiPoAng;
    float KdPoAng;
    float KiPoAngSat; //Saturation value for integral term
    
    Serial& pc;
    
};

#endif
 