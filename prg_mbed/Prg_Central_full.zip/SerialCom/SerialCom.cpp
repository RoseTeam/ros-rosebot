#include "SerialCom.h"
#include "mbed.h"



SerialCom::SerialCom(Serial& _pc) : pc(_pc){
    // incomming_message_type = 0;     
     //nbr_incom_char = 0;          
    sign = false;
    pc.baud(115200);
    initCst();   // inititate mtotor Ctrl Constants to define values in the .h, waiting for further notice from the COM
     
}
        
        
void SerialCom::serialCallback()
{          
  while(pc.readable()) 
    {   
    
        char c = pc.getc();            
           //pc.printf("%i-",c);
        if (incomming_message_type != 0)   //if it is not the first bit of the packet
        { 
       // pc.printf("D%c!",c);
            if (nbr_incom_char < NBR_CHAR_NAV)
                {                           
                if(c>= 47 &&  c < 58) // if the character received is a number                    
                    {
                        inputString[nbr_incom_char] = c;                    
                        nbr_incom_char++;
                        //pc.printf("D:!");
                        //pc.printf("g");  
                    }
                else if(c == '!')   //if the character received is end of the packet
                    {
                        inputString[nbr_incom_char] = c;                    
                        nbr_incom_char++;
                        interpretData(); 
                        nbr_incom_char = 0; //pc.printf("\n");   
                        sign = false;
                         //pc.printf("D[!");
                    }
                else if (c == 45)
                   { sign = true;}
                else                // charachter not recognized, we cancel
                    {
                        incomming_message_type = 0;
                        nbr_incom_char = 0;
                        sign = false;
                         
                        
                        //pc.printf("def");  
                    }                                            
                }
            else
                {//default , packet overwhelmed
                pc.printf("Ddef_o!");
                nbr_incom_char = 0;
                incomming_message_type = 0;
                sign = false;
                }
        }
        else //if it is the first bit of the packet, check if it is a standard message
        {
            if (c == 'X' || c == 'Y' || c == 'A' || c == 'L' || c == 'R' || c == 'T' || c == 'V' || c == 'S' || c == 'U')    // if one of the packet header is known
                { incomming_message_type = c;  }  //order merssages 
            else if (c == '{' || c == '-' || c == '}' || c == '(' || c == '_' || c == ')' || c == '=' || c == '|')      // if one of the packet header is known and rarely used  
                { incomming_message_type = c; /*pc.printf("u");*/ }
            else 
                {
                 //Unknown incomming data   
                }
        }
    }
   
           
 }

//Function to be called when we have received the full packet
int SerialCom::interpretData(){    
        int i = 0;
        long incom_data = 0; 

       
        while(inputString[i] != '!')                
            { 
            char incom_byte = inputString[i]-48;
            
            if (incom_byte >= 0 &&  incom_byte < 10)
                { incom_data = incom_data*10 + incom_byte;}
            else
                { 
                //default nbr received
                }                         
            i++;
            }
        if(sign) {  incom_data = -incom_data; }
        
        if (incomming_message_type == 'X') {Xorder = incom_data; /*myled = !myled; pc.printf("%i",Xorder);*/}
        else if (incomming_message_type == 'Y') {Yorder = incom_data;}
        else if (incomming_message_type == 'A') {Aorder = incom_data;}
        else if (incomming_message_type == 'L') {Lspeed = incom_data;}
        else if (incomming_message_type == 'R') {Rspeed = incom_data;}
        else if (incomming_message_type == 'T') {Ttwist = incom_data/10; }//pc.printf("DT11!",incom_data);}
        else if (incomming_message_type == 'V') {Vtwist = incom_data/100; } //pc.printf("DV55!",incom_data);}
        else if (incomming_message_type == 'S') {SStatus = incom_data; stateCheck();}
        else if (incomming_message_type == 'U') {UPower = (bool)incom_data;}
        
        else if (incomming_message_type == '{') {KpPoLin = incom_data/1000.0;}
        else if (incomming_message_type == '}') {KdPoLin = incom_data/1000.0;}
        else if (incomming_message_type == '^') {KiPoLin = incom_data/1000.0;}
        else if (incomming_message_type == '=') {KiPoLinSat = incom_data/1000.0;}
        else if (incomming_message_type == '(') {KpPoAng = incom_data/1000.0;}
        else if (incomming_message_type == ')') {KdPoAng = incom_data/1000.0;}
        else if (incomming_message_type == '_') {KiPoAng = incom_data/1000.0;}
        else if (incomming_message_type == '|') {KiPoAngSat = incom_data/1000.0;}
               
        incomming_message_type = 0;
        nbr_incom_char = 0;
        sign = false;
           
    return 1;
}

void SerialCom::sendFeedback(long pidL, long pidR, float pidA, float pidT){
    /*pc.printf("DL%ld!",long(Ttwist));
        pc.printf("DR%ld!",long(Vtwist));
        pc.printf("DA%lf!", pidA);
        pc.printf("DT%lf!", pidT);*/
        pc.printf("Dp: %lf!", KpPoLin);
        pc.printf("Dd: %lf!", KdPoLin);
        pc.printf("Di :%lf!", KiPoLin );
        pc.printf("Ds: %lf!", KiPoLinSat);
        
        
         
        //pc.printf("D{%lf!", KpPoAng);
        pc.printf("D!");
}

int SerialCom::getTtwist(){
    return Ttwist;
}

int SerialCom::getVtwist(){
    return Vtwist;
}

int SerialCom::getSStatus(){
    return SStatus;
}

bool SerialCom::getUPower(){
    return UPower;
}



float SerialCom::getKpPoLin(){    
    return KpPoLin;
}

float SerialCom::getKiPoLin(){
    return KiPoLin;
}

float SerialCom::getKdPoLin(){   
    return KdPoLin;
}

float SerialCom::getKiPoLinSat(){
    return KiPoLinSat;
}
    
float SerialCom::getKpPoAng(){
    return KpPoAng;
}
    
float SerialCom::getKiPoAng(){
    return KiPoAng;
}

float SerialCom::getKdPoAng(){
    return KdPoAng;
}

float SerialCom::getKiPoAngSat(){
    return KiPoAngSat;
}

bool SerialCom::initCst(){
    KpPoAng = KP_POLAR_ANGLE;
    KiPoAng = KI_POLAR_ANGLE;
    KdPoAng = KD_POLAR_ANGLE;
    KiPoAngSat = KI_POLAR_ANGLE_SAT;
    
    KpPoLin = KP_POLAR_LINEAR;
    KiPoLin = KI_POLAR_LINEAR;
    KdPoLin = KD_POLAR_LINEAR;
    KiPoLinSat = KI_POLAR_LINEAR_SAT;
    
    return true;
}    

 int SerialCom::stateCheck(){
    if(SStatus == 0)
    {   
        NVIC_SystemReset();
    }  
    
}
    


